/*
 *  Check for OpenGL errors
 */
#include "CSCIx229.h"

void ErrCheck(const char* where)
{
   int err = glGetError();
   if (err) printf("ERROR: %s [%s]\n",gluErrorString(err),where);
}
